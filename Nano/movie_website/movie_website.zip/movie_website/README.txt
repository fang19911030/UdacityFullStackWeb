The python version: 3.5
The needed package: webbrowser

The CSS file and HTML file is included in the fresh_tomatoes.py

To add movies you need add new media.Movie objects to the list of movies, this part is belong to entertainment_center.py 

Usage: 

First step: make sure you are at the entertainment_center.py doucument route

Second step: $python entertainment_center.py

or you can run entertainment_center at your python IDE.